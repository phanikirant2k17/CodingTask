package com.crossover.e2e;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import junit.framework.TestCase;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GMailTest extends TestCase {
    private WebDriver driver;
    private Properties properties = new Properties();

    public void setUp() throws Exception {
    	
    	// declaration and instantiation of objects/variables and launch chrome
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\qa-automation-selenium-java\\Resources\\chromedriver.exe");
        
        driver = new ChromeDriver();
        
        // loading test.properties
        properties.load(new FileReader(new File("test.properties")));
    }

    public void tearDown() throws Exception {
        driver.quit();
    }

    @Test
    public void testSendEmail() throws Exception {
    	
    	// to maximize window
    	driver.manage().window().maximize();
    	
    	// direct it to the URL
        driver.get("https://mail.google.com/");
        
        // identifying the column of username and sending the keys
        WebElement userElement = driver.findElement(By.id("identifierId"));
        userElement.sendKeys(properties.getProperty("username"));

        System.out.println("1. Entered the user name");
        
        // to find the 'next' web element
        driver.findElement(By.id("identifierNext")).click();

        driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
        
        // identifying the column of password and sending the keys
        WebElement passwordElement = driver.findElement(By.name("password"));
        WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(passwordElement));
        passwordElement.sendKeys(properties.getProperty("password"));
        
        // to find the 'next' web element
        driver.findElement(By.id("passwordNext")).click();
        System.out.println("2. Entered the password and click on login");

        driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

        
        // to click on compose button
		driver.findElement(By.cssSelector(".aic .z0 div")).click();
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		// to send the keys of 'to' i.e; recipient
		driver.findElement(By.xpath("//*[starts-with(@name,'to')]")).sendKeys(properties.getProperty("username")+"@gmail.com");
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		String s = RandomStringUtils.randomAlphabetic(8);
		// sending keys to subject and body
		String subject = "GmailTestScript" + s;
		String body = "Assignment Task";

		driver.findElement(By.xpath("//*[starts-with(@name,'subjectbox')]")).sendKeys(subject);
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		driver.findElement(By.cssSelector(".Am.Al.editable.LW-avf")).sendKeys(body);
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		// to click on more options to label it as 'social'
		WebElement moreoptions = driver.findElement(By.cssSelector("div[data-tooltip='More options']"));
		moreoptions.click();

		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		WebElement label = driver.findElement(By.cssSelector("span[class='J-Ph-hFsbo']"));
		String javaScript = "var evObj = document.createEvent('MouseEvents');"
				+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
				+ "arguments[0].dispatchEvent(evObj);";

		((JavascriptExecutor) driver).executeScript(javaScript, label);
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("input[class='bqf']")).sendKeys("social");
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		driver.findElement(By.cssSelector("div[title='Social']")).click();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		Thread.sleep(5000);
		driver.findElement(By.cssSelector(".T-I.J-J5-Ji.aoO.T-I-atl.L3")).click();

		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		System.out.println("3. Sent an Email with Unique Subject and marked the lable as Social");

		driver.findElement(By.cssSelector("td[class*='aRz'] div[aria-label='Social']")).click();
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		
		System.out.println("4. Navigated to Social Tab");
		
		
		//to search the Email matches with the Email Subject
		WebElement searchele = driver.findElement(By.name("q"));
		searchele.sendKeys(subject);

		searchele.sendKeys(Keys.ENTER);
		
		System.out.println("5. Searched with the keyword as Email Subject");

		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		WebElement sentemailelement = driver
				.findElement(By.cssSelector("div[class='ae4 UI'] div[class='Cp'] div table tbody tr"));
		sentemailelement.click();
		
		System.out.println("6. Found the Email matches with the searched Email Subject");
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);

		WebElement Starelement  = driver.findElement(By.cssSelector("span[class='T-KT']"));
		Starelement.click();
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
		
		System.out.println("7. Email Marked as Starred");
		
		//to verify the subject and body of the received email
		String BodyOfEmail = driver.findElement(By.cssSelector("div[class*='a3s'] div[dir='ltr']")).getText();
		
		
		if(BodyOfEmail.equalsIgnoreCase(body)) {
		System.out.println("8. Body of the email verified");
		System.out.println("Test script pass");
		}
		else
		{
			System.out.println("Body Info of the email is mismatched");
			System.out.println("Test script Failed");
		}
		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
    
    	
		// to mark email as starred 	
  		driver.findElement(By.xpath("//*[contains(@id,':ot')]")).click();
  		driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
  		
  		
    }	
    
}
